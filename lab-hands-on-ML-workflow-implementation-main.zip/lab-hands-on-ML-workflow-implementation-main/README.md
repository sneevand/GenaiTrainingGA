## **ML Workflow Implementation for Client Recommendations**

**Lab Objective:**

Build, train, and evaluate a machine learning pipeline for predicting customer churn and provide actionable insights for
the client.

**Scenario:**

"Your retail client has provided customer behavior data and needs a predictive model to identify at-risk customers. Your
task is to build the model and prepare a presentation summarizing findings and recommendations."

**In this lab you will:**

- Perform EDA to understand patterns in the dataset.
- Build a supervised learning pipeline for churn prediction.
- Evaluate the model using metrics like precision, recall, and F1-score.
- Prepare a short "client update" slide or document summarizing key insights and proposed actions (e.g., loyalty program
  tweaks or targeted marketing campaigns).

### Lab Setup Instructions

1. **Navigate to the Project Directory:**
   ```bash
   cd lab-hands-on-ML-workflow-implementation
   ```

2. **Create a Virtual Environment:**
   ```bash
   python3 -m venv env
   ```

3. **Activate the Virtual Environment:**
   ```bash
   source env/bin/activate
   ```

4. **Install Required Packages:**
   ```bash
   pip install -r requirements.txt
   ```

5. **Launch Jupyter Notebook:**
   ```bash
   jupyter notebook
   ```

6. **Open the Starter IPython Notebook:**
    - In the Jupyter interface, navigate to the starter notebook to begin the lab.