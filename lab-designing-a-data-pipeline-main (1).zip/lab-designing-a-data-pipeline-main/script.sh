# Create and activate virtual environment
python3.11 -m venv airflow_env
source airflow_env/bin/activate

# Install Apache Airflow with SQLite provider
pip install "apache-airflow[sqlite]==2.6.2" --constraint "https://raw.githubusercontent.com/apache/airflow/constraints-2.6.2/constraints-3.11.txt"
pip install pandas

# Initialize Airflow database
airflow db init

# Create Airflow admin user
airflow users create \
    --username admin \
    --password admin \
    --firstname Admin \
    --lastname User \
    --role Admin \
    --email admin@example.com

# Set up data directory
export DATA_DIR=/home/$(whoami)/data
mkdir -p $DATA_DIR

# Create SQLite database
sqlite3 $DATA_DIR/demo.db ".exit"

# Start Airflow in standalone mode
airflow standalone