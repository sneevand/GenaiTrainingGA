#!/bin/bash
# Use -e with caution to prevent early exits on permission errors
# set -e

# Check if we should skip requirements installation
SKIP_REQUIREMENTS=${SKIP_REQUIREMENTS:-"false"}

# Check if we're running as root
if [ "$(id -u)" = "0" ]; then
    echo "Running as root user. Will try to set permissions."
    IS_ROOT=true
else
    echo "Running as non-root user ($(id -u):$(id -g)). Will skip permission changes."
    IS_ROOT=false
fi

# Check if virtual environment exists and activate it
if [ -f /app/venv/bin/activate ]; then
    echo "Activating virtual environment..."
    source /app/venv/bin/activate
else
    echo "WARNING: Virtual environment not found at /app/venv/bin/activate"
    if [ "$SKIP_REQUIREMENTS" != "true" ]; then
        echo "Installing requirements (set SKIP_REQUIREMENTS=true to skip)..."
        pip install -r /app/requirements.txt || echo "Warning: Failed to install requirements"
    else
        echo "Skipping requirements installation as requested"
    fi
fi

# Create data directory with proper permissions - handle errors gracefully
echo "Creating data directory..."
mkdir -p /app/data 2>/dev/null || echo "Warning: Could not create /app/data directory"

# Only try to set permissions if running as root
if [ "$IS_ROOT" = true ]; then
    # Try to set permissions but don't fail if it doesn't work
    chmod 777 /app/data 2>/dev/null || echo "Warning: Could not set permissions on /app/data"
fi

# Function to check if a file exists
file_exists() {
    [ -f "$1" ]
}

# Create symbolic links for lab data directories - handle errors gracefully
for lab in lab1.4 lab2.4 lab3.3 lab4.3 lab4.4 lab5.4; do
    mkdir -p /app/$lab/data 2>/dev/null || echo "Warning: Could not create /app/$lab/data directory"
    
    # Only try to set permissions if running as root
    if [ "$IS_ROOT" = true ]; then
        # Try to set permissions but don't fail if it doesn't work
        chmod 777 /app/$lab/data 2>/dev/null || echo "Warning: Could not set permissions on /app/$lab/data"
    fi
done

# Function to safely copy files with error handling
safe_copy() {
    local src="$1"
    local dest="$2"
    local link="$3"
    
    if [ -f "$src" ]; then
        echo "Using original $(basename $src) from $(dirname $src)"
        if cp "$src" "$dest" 2>/dev/null; then
            echo "Successfully copied $(basename $src) to $dest"
            if [ -n "$link" ]; then
                ln -sf "$dest" "$link" 2>/dev/null || echo "Warning: Could not create symlink from $dest to $link"
            fi
        else
            echo "Warning: Could not copy $src to $dest due to permissions"
            echo "The file exists but will be used directly from its original location"
            # If we can't copy, we'll just use the original file
            if [ -n "$link" ] && [ "$src" != "$link" ]; then
                ln -sf "$src" "$link" 2>/dev/null || echo "Warning: Could not create symlink from $src to $link"
            fi
        fi
        return 0
    else
        echo "ERROR: Required file $src not found"
        echo "Please ensure all required data files are present in their respective lab directories"
        return 1
    fi
}

# Lab 1.4: Customer Churn Data - don't exit on failure
if ! safe_copy "/app/lab1.4/data/retail-sales-data.csv" "/app/data/retail-sales-data.csv" "/app/lab1.4/data/retail-sales-data.csv"; then
    echo "Warning: Could not process retail-sales-data.csv, but continuing..."
fi

# Lab 2.4: Text Data - don't exit on failure
if ! safe_copy "/app/lab2.4/data/prod_reviews.csv" "/app/data/prod_reviews.csv" "/app/lab2.4/data/prod_reviews.csv"; then
    echo "Warning: Could not process prod_reviews.csv, but continuing..."
fi

# Lab 4.4: Fraud Detection Data - don't exit on failure
if ! safe_copy "/app/lab4.4/data/fraud_detection_dataset.csv" "/app/data/fraud_detection_dataset.csv" "/app/lab4.4/data/fraud_detection_dataset.csv"; then
    echo "Warning: Could not process fraud_detection_dataset.csv, but continuing..."
fi

# Lab 5.4: Hospital Readmissions Data - don't exit on failure
if ! safe_copy "/app/lab5.4/data/hospital_readmissions_data.csv" "/app/data/hospital_readmissions_data.csv" "/app/lab5.4/data/hospital_readmissions_data.csv"; then
    echo "Warning: Could not process hospital_readmissions_data.csv, but continuing..."
fi

# Lab 3.3: Database file - don't exit on failure
echo "Processing demo.db file for lab3.3..."
if ! safe_copy "/app/lab3.3/data/demo.db" "/app/data/demo.db" "/app/lab3.3/data/demo.db"; then
    echo "Warning: Could not process demo.db, but continuing..."
fi

# Initialize and start Airflow
echo "Initializing Airflow database..."
export AIRFLOW_HOME=/app/airflow
mkdir -p $AIRFLOW_HOME 2>/dev/null || echo "Warning: Could not create Airflow home directory"
mkdir -p $AIRFLOW_HOME/dags 2>/dev/null || echo "Warning: Could not create Airflow dags directory"

# Initialize Airflow database
airflow db init || echo "Warning: Failed to initialize Airflow database, but continuing..."

# Create Airflow admin user if it doesn't exist
if ! airflow users list | grep -q "admin"; then
    echo "Creating Airflow admin user..."
    airflow users create \
        --username admin \
        --password admin \
        --firstname Admin \
        --lastname User \
        --role Admin \
        --email admin@example.com || echo "Warning: Failed to create Airflow user, but continuing..."
fi

# Start Airflow in standalone mode in the background
echo "Starting Airflow in standalone mode..."
airflow standalone &
AIRFLOW_PID=$!
echo "Airflow started with PID: $AIRFLOW_PID"
echo "Airflow UI will be available at http://localhost:8080"

# Start Jupyter Notebook
echo "Starting Jupyter Notebook..."
jupyter notebook --ip=0.0.0.0 --port=8888 --no-browser --allow-root --NotebookApp.token='' --NotebookApp.password=''

# Keep container running
echo "Environment is ready!"
echo "Jupyter Notebook is running at http://localhost:8888"
echo "Airflow is running at http://localhost:8080"
echo "To use VSCode with this container, run: code . -n"
echo "Press Ctrl+C to stop the container"

# Wait for all background processes to complete
wait 