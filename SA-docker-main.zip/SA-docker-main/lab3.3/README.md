<h1>
  <span class="prefix"></span>
  <span class="headline">[tktk Headline]</span>
</h1>

## About

tktk Write a short but descriptive summary of the content in this module. Introduce the lab. What will the students build in this lab?

## Content

- [Setup](./setup/README.md)
- [Exercise](./exercise/README.md)

## Internal

### Prerequisites

- tktk

### Time to complete

Estimated time to complete core lab exercise: **tktk min**

### Starter code

tktk If there is not a starter code repo that students will fork and clone to start this lab, then this section and all of its content should be removed.

🟢 [Starter code](https://git.generalassemb.ly/modular-curriculum-all-courses/tktk)

### Solution code

🏁 [Solution code](https://git.generalassemb.ly/modular-curriculum-all-courses/tktk)

### Deployed sites

tktk If there is not a deployed site related to this module this section and all of its content should be removed.

🌐 [Live site](https://generalassemb.ly/tktk)

### Course landing pages

- [tktk-course-acronym - tktk Course Full Name](https://pages.git.generalassemb.ly/modular-curriculum-all-courses/tktk-module-name/canvas-landing-pages/tktk-course-acronym.html)
- [Fallback](https://pages.git.generalassemb.ly/modular-curriculum-all-courses/tktk-module-name/canvas-landing-pages/fallback.html)

### Resources

✏️ [Instructor Guide](./internal-resources/instructor-guide.md)

🎥 [Video Hub](./internal-resources/video-hub.md)

🏗️ [Release Notes](./internal-resources/release-notes.md)

---

**Find a 👾 bug 👾 or have suggestions? [Let us know](https://pages.git.generalassemb.ly/modular-curriculum-all-courses/universal-resources-internal/module-feedback.html)!**
