import { runLinter } from 'ga-mdlint'

runLinter()
