<h1>
  <span class="headline">[tktk Headline]</span>
  <span class="subhead">Setup</span>
</h1>

## Setup

tktk The below is a generic starting point for lab setup. You may need to make adjustments to this.

Open your Terminal application and navigate to your <code class="filepath">~/code/ga/labs</code> directory:

```bash
cd ~/code/ga/labs
```

### Fork and clone the starter code

tktk Use the below instructions if students will need starter code from a separate module to complete the lab exercise. If they do not, delete this section and all of its contents.

Fork the [[tktk Headline] Starter Code](https://git.generalassemb.ly/modular-curriculum-all-courses/tktk-module-name-starter-code) repository.

Clone a copy of your remote repo locally by using the `git clone` command:

```bash
git clone https://git.generalassemb.ly/<your-username>/tktk-module-name-starter-code.git tktk-module-name
```

Replace `<your-username>` (including the `<` and `>`) with your General Assembly GitHub Enterprise username before you run this command.

### Create and clone a GitHub repo

tktk Use the below instructions if students do not need starter code from a separate module to complete the lab exercise. If they do, delete this section and all of its contents.

Make a new repository on [GitHub](https://github.com/) named `tktk-module-name`.

Clone a copy of your remote repo locally by using the `git clone` command:

```bash
git clone https://github.com/<your-username>/tktk-module-name.git
```

Replace `<your-username>` (including the `<` and `>`) with your GitHub username before you run this command.

### Launch in VS Code

Next, `cd` into the cloned directory, <code class="filepath">tktk-module-name</code>:

```bash
cd tktk-module-name
```

Open the contents of the directory in VS Code:

```bash
code .
```

tktk Are there more lab setup steps? Don't forget to add them here.
