# Solutions Architect AI Course Labs in a Docker Environment

This repository contains a Docker-based environment for running the Strategic AI course labs. The environment includes Jupyter Notebook and VSCode integration, with all necessary dependencies pre-installed.

## Goal

Provide a seamless, fully automated environment for all labs and hands-on exercises in the SA AI Course, being extensible to other projects. By leveraging Docker, we aim to eliminate the complexity of environment setup—allowing students and instructors to focus on building AI solutions rather than troubleshooting dependencies.

## Prerequisites

- Docker (version 25.0.6 or later)
- AWS Workspace with Amazon Linux 2 (or any system with Docker installed)

## Quick Start

1. Clone this repository:
   ```bash
   git clone https://git.generalassemb.ly/ENT-Solutions-Architect/SA-docker.git
   cd SA-docker
   ```

2. Make the setup script executable:
   ```bash
   chmod +x setup.sh
   ```

3. Run the setup script with sudo (recommended for AWS Workspace):
   ```bash
   sudo ./setup.sh
   ```

This will:
- Build the Docker image
- Start a container with Jupyter Notebook accessible at http://localhost:8888
- Start a container with Airflow at http://localhost:8080
- Create helper scripts for VSCode integration

If you encounter build issues and need to start fresh, use the cleanup option:
```bash
sudo ./setup.sh --clean
```

## Container Management

If your machine restarts or you need to stop and restart the container without rebuilding everything, follow these steps:

### Checking Container Status

To check if your container is running:
```bash
sudo docker ps
```

To see all containers (including stopped ones):
```bash
sudo docker ps -a
```

### Starting and Stopping the Container

If the container exists but is stopped:
```bash
sudo docker start sa-course-labs
```

To stop the container without removing it:
```bash
sudo docker stop sa-course-labs
```

## Using the Environment

### Jupyter Notebook

- Access Jupyter Notebook at http://localhost:8888
- No password or token is required
- All lab directories are available in the Jupyter interface

### Working with VSCode and the Container

To use VSCode with the container's Python environment:

1. **Start the container** (if not already running):
   ```bash
   sudo ./setup.sh
   ```

2. **Open VSCode** in a new terminal:
   ```bash
   ./open-vscode.sh
   ```

3. **Access the container's Python environment** using one of these methods:

   **Option A: Open a terminal in the container**
   ```bash
   sudo docker exec -it sa-course-labs bash
   ```
   Once inside, you can run Python directly with all packages available.

   **Option B: Run Python scripts directly**
   ```bash
   ./run-in-container.sh lab1.4/my_script.py
   ```
   This runs a Python script using the container's environment without entering it.

   **Option C: Use VSCode's terminal**
   1. Open a terminal in VSCode (Terminal > New Terminal)
   2. Run: `sudo docker exec -it sa-course-labs bash`
   3. Now you can run Python commands with all packages available

### Workflow Example

1. Start the container: `sudo ./setup.sh`
2. Open Jupyter in your browser: http://localhost:8888
3. Open VSCode in a new terminal: `./open-vscode.sh`
4. Edit files in VSCode
5. Run scripts in the container: `./run-in-container.sh your_script.py`
6. Or open a terminal in the container to run commands interactively

## Lab Structure

The environment includes the following labs:

- lab1.4: Machine Learning Pipeline for Customer Churn Prediction
- lab2.4: NLP with TensorFlow
- lab3.3: Data Pipeline with Apache Airflow
- lab4.3: MLOps Lab
- lab4.4: MLflow for Model Tracking and Deployment
- lab5.4: Capstone Project

## Data Files

The environment requires the following original data files to be present in their respective lab directories:

- **lab1.4/data/retail-sales-data.csv** - For customer churn prediction
- **lab2.4/data/prod_reviews.csv** - For NLP analysis
- **lab4.4/data/fraud_detection_dataset.csv** - For fraud detection
- **lab5.4/data/hospital_readmissions_data.csv** - For hospital readmissions prediction

If any of these files are missing, the container will exit with an error message. Please ensure all required data files are present before starting the container.

The entrypoint script will:
1. Copy these files to the `/app/data` directory
2. Create symbolic links to make them accessible with the expected names in each lab's data directory

## Technical Details

- Python version: 3.11.9
- Package management: uv for dependency resolution
- Key packages:
  - scikit-learn ≥1.3.0
  - pandas 1.3.5
  - matplotlib 3.5.3
  - tensorflow 2.15.0
  - mlflow 2.10.0

> **Note about Apache Airflow**: Due to dependency conflicts between TensorFlow, MLflow, and Apache Airflow (specifically with protobuf versions), Airflow is not pre-installed in this Docker image. For the Airflow lab (lab3.3), please follow the installation instructions in the lab README, which will guide you through installing Airflow directly on your AWS Workspace rather than in the Docker container.

## Troubleshooting

### Docker Permission Issues

If you encounter permission errors when running Docker commands:

```
ERROR: permission denied while trying to connect to the Docker daemon socket
```

In AWS Workspace environments, the simplest solution is to use `sudo` with Docker commands:

```bash
sudo ./setup.sh
```

The setup script will automatically try to use `sudo` for Docker commands if needed, but it's recommended to run the script with sudo directly in AWS Workspace environments.

> **Note**: While adding your user to the docker group (`sudo usermod -aG docker $USER`) is typically recommended for long-term use, this approach may not work in some AWS Workspace environments due to security configurations.

### Virtual Environment Issues

If you encounter issues with the virtual environment:

```
/app/entrypoint.sh: line 5: /app/venv/bin/activate: No such file or directory
```

Try cleaning up and rebuilding:

```bash
sudo ./setup.sh --clean
```

The entrypoint script is designed to fall back to using the system Python if the virtual environment is not found, but rebuilding with the clean option is the recommended solution.

### Python Package Compatibility

If you encounter issues with package compatibility:

1. TensorFlow 2.15.0 is used because it's compatible with Python 3.11. Earlier versions of TensorFlow (like 2.11.0) don't support Python 3.11.
2. MLflow 2.10.0 is used because it's compatible with Python 3.11 and has fewer dependency conflicts than earlier versions.
3. scikit-learn ≥1.3.0 is used because newer versions have fixed many Cython-related build issues that can occur with older versions like 1.0.2.
4. Apache Airflow is not included in the Docker image due to irreconcilable dependency conflicts with TensorFlow and MLflow:
   - TensorFlow and MLflow require protobuf <5.0
   - Airflow's OpenTelemetry components require protobuf >=5.0
   - These conflicting requirements cannot be satisfied simultaneously
5. For the Airflow lab, please follow the lab-specific instructions to install Airflow directly on your AWS Workspace.

### Port Conflicts

If port 8888 is already in use, modify the `setup.sh` script to use a different port:

```bash
sudo docker run -it --rm -p <new-port>:8888 -v "$(pwd):/app" --name sa-course-labs sa-course-labs
```

Then access Jupyter at http://localhost:<new-port>

### Permission Issues

If you encounter permission issues with the mounted volume:

```bash
sudo docker run -it --rm -p 8888:8888 -v "$(pwd):/app:Z" --name sa-course-labs sa-course-labs
```

The `:Z` flag helps with SELinux contexts on some systems.

### Data File Issues

If you encounter issues with the data files:

1. Check if the data directories exist in each lab folder:
   ```bash
   sudo docker exec -it sa-course-labs ls -la /app/lab1.4/data
   ```

2. Verify the symbolic links are correctly set up:
   ```bash
   sudo docker exec -it sa-course-labs ls -la /app/lab1.4/data
   ```

3. If needed, manually copy the data files:
   ```bash
   sudo docker exec -it sa-course-labs cp /app/data/customer_churn.csv /app/lab1.4/data/
   ```

### Container Not Starting

If the container fails to start, check the Docker logs:

```bash
sudo docker logs sa-course-labs
```

## Customization

### Adding New Dependencies

To add new Python packages:

1. Edit the `requirements.txt` file
2. Rebuild the Docker image:
   ```bash
   sudo docker build -t sa-course-labs .
   ```

### Modifying the Environment

To make changes to the Docker environment:

1. Edit the `Dockerfile`
2. Rebuild the Docker image:
   ```bash
   sudo docker build -t sa-course-labs .
   ```

### Adding Custom Data Files

To add your own data files:

1. Create a `data` directory in your repository
2. Place your CSV files in the `data` directory
3. Run the container - your files will be used instead of the sample ones
