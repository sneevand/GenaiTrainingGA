#!/bin/bash
set -e

# Function to handle exit signals
cleanup() {
    echo -e "\n\nReceived exit signal. Stopping container..."
    $DOCKER_CMD stop sa-course-labs 2>/dev/null || true
    echo "Container stopped. Exiting setup script."
    exit 0
}

# Trap SIGINT (Ctrl+C) and SIGTERM
trap cleanup SIGINT SIGTERM

# Check if Docker is installed
if ! command -v docker &> /dev/null; then
    echo "Docker is not installed. Please install Docker first."
    exit 1
fi

# Create data directory if it doesn't exist
if [ ! -d "./data" ]; then
    echo "Creating data directory..."
    mkdir -p ./data
    echo "Data directory created. You can place your CSV files here."
fi

# Determine if we should use sudo based on OS
if [[ "$OSTYPE" == "darwin"* ]]; then
    # macOS doesn't need sudo for Docker
    DOCKER_CMD="docker"
    echo "Running on macOS, using docker without sudo"
else
    # For Linux/AWS Workspace environments, use sudo
    DOCKER_CMD="sudo docker"
    echo "Using sudo for Docker commands (recommended for Linux/AWS Workspace)"
fi

# Check if we need to clean up a previous failed build
if [ "$1" == "--clean" ]; then
    echo "Cleaning up previous Docker images and containers..."
    $DOCKER_CMD rm -f sa-course-labs 2>/dev/null || true
    $DOCKER_CMD rmi -f sa-course-labs 2>/dev/null || true
    echo "Cleanup completed."
fi

# Check if we should skip requirements installation
SKIP_REQS="false"
if [ "$1" == "--skip-reqs" ] || [ "$2" == "--skip-reqs" ]; then
    SKIP_REQS="true"
    echo "Will skip requirements installation to speed up testing"
fi

# Create a simple script to open VSCode
cat > open-vscode.sh << EOF
#!/bin/bash
# Check if the container is running
if ! $DOCKER_CMD ps | grep -q sa-course-labs; then
    echo "Error: The sa-course-labs container is not running."
    echo "Please run the container first with: ./setup.sh"
    exit 1
fi

echo "Opening VSCode in the current directory..."

# Open VSCode as the regular user
if [ -n "$SUDO_USER" ]; then
    # If running with sudo, run VSCode as the original user
    su - $SUDO_USER -c "cd $(pwd) && code ."
else
    # Otherwise run as current user
    code .
fi

echo ""
echo "===== ACCESSING THE CONTAINER'S PYTHON ENVIRONMENT ====="
echo ""
echo "Here's how to access the Python environment in the container:"
echo ""
echo "Create a terminal in VSCode that connects to the container"
echo "  1. In VSCode, open a terminal (Terminal > New Terminal)"
echo "  2. Run: $DOCKER_CMD exec -it sa-course-labs bash"
EOF
chmod +x open-vscode.sh

# Create a helper script to run Python in the container
cat > run-in-container.sh << EOF
#!/bin/bash
# This script runs a Python file in the container

if [ $# -eq 0 ]; then
    echo "Usage: ./run-in-container.sh <python_file.py> [args...]"
    echo "Example: ./run-in-container.sh lab1.4/my_script.py"
    exit 1
fi

SCRIPT_PATH="$1"
shift  # Remove the first argument (the script path)

# Run the Python script in the container
$DOCKER_CMD exec -it sa-course-labs python "/app/$SCRIPT_PATH" "$@"
EOF
chmod +x run-in-container.sh

# Build the Docker image
echo "Building Docker image..."
$DOCKER_CMD build -t sa-course-labs .

# Print instructions for exiting
echo -e "\n===== IMPORTANT: HOW TO EXIT =====\n"
echo "To exit the container and this script:"
echo "1. Press Ctrl+C in this terminal"
echo "2. Or run '$DOCKER_CMD stop sa-course-labs' from another terminal"
echo -e "\n================================\n"

# Get current user ID and group ID for volume permissions
USER_ID=$(id -u)
GROUP_ID=$(id -g)

# Run the Docker container with a name to make it easier to stop
echo "Running Docker container with user ID $USER_ID and group ID $GROUP_ID..."
echo "Skip requirements installation: $SKIP_REQS"

$DOCKER_CMD run -it \
    -p 8888:8888 \
    -p 8080:8080 \
    -v "$(pwd):/app" \
    -u $USER_ID:$GROUP_ID \
    -e SKIP_REQUIREMENTS=$SKIP_REQS \
    --name sa-course-labs \
    sa-course-labs

# If we get here, the container has exited normally
echo "Container has exited. Cleaning up..."
$DOCKER_CMD rm -f sa-course-labs 2>/dev/null || true