# MLOps Workflow for Deploying Predictive Models in Client Projects

### Lab Objective:

Implement and manage an end-to-end MLOps workflow to deploy a scalable fraud detection model for a financial services
client.

### Scenario:

A financial services client requires a fraud detection model that can be deployed across multiple regions with minimal
downtime. Your team is responsible for managing the deployment, ensuring model version control, and optimizing
performance.

### In this lab, students will:

- Utilize MLflow to track experiments, hyperparameters, and model versions.
- Deploy the top-performing model in a simulated production environment.

### Lab Setup Instructions

1. **Navigate to the Project Directory:**
   ```bash
   cd day-4-capstone-lab
   ```

2. **Create a Virtual Environment:**
   ```bash
   python3 -m venv env
   ```

3. **Activate the Virtual Environment:**
   ```bash
   source env/bin/activate
   ```

4. **Install Required Packages:**
   ```bash
   pip install -r requirements.txt
   ```

5. **Launch Jupyter Notebook:**
   ```bash
   jupyter notebook --ip=0.0.0.0 --port=8888 --allow-root --NotebookApp.token='' --NotebookApp.password=''
   ```

6. **Open the Starter IPython Notebook:**
    - In the Jupyter interface, navigate to the starter notebook to begin the lab.

7. **Start the MLflow Tracking Server**
   - Open a new terminal and activate the virtual environment 
   - Run the following command: `mlflow server --host 127.0.0.1 --port 5000`
   - This will launch the MLflow tracking UI at [http://127.0.0.1:5000](http://127.0.0.1:5000).
