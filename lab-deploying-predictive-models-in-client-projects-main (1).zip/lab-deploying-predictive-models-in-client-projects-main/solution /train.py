import pandas as pd
import mlflow
import mlflow.sklearn
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, f1_score


def load_and_preprocess_data(data_path):
    """Load and preprocess the fraud detection dataset."""
    print(f"Loading data from {data_path}")
    data = pd.read_csv(data_path)
    print("Data loaded successfully. Shape:", data.shape)
    
    # One-hot encode categorical features
    type_new = pd.get_dummies(data['type'], drop_first=True)
    data_new = pd.concat([data, type_new], axis=1)
    
    # Split features and target
    X = data_new.drop(['isFraud', 'type', 'nameOrg', 'nameDest'], axis=1)
    y = data_new['isFraud']
    
    # Split data into train and test sets
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)
    print(f"Train set: {X_train.shape}, Test set: {X_test.shape}")
    
    return X_train, X_test, y_train, y_test


def train_and_log_model(model, model_name, X_train, y_train, X_test, y_test):
    """Train a model and log it to MLflow."""
    # The key is to use mlflow.start_run() to create a new run
    with mlflow.start_run(run_name=model_name):
        print(f"Training {model_name}...")
        
        # Train the model
        model.fit(X_train, y_train)
        
        # Predict and calculate metrics
        predictions = model.predict(X_test)
        accuracy = accuracy_score(y_test, predictions)
        f1 = f1_score(y_test, predictions)
        
        print(f"{model_name} - Accuracy: {accuracy:.4f}, F1 Score: {f1:.4f}")
        
        # Log parameters
        mlflow.log_param("model_name", model_name)
        
        # For RandomForest, log additional parameters
        if isinstance(model, RandomForestClassifier):
            mlflow.log_param("n_estimators", model.n_estimators)
            mlflow.log_param("max_depth", model.max_depth)
        
        # Log metrics
        mlflow.log_metric("accuracy", accuracy)
        mlflow.log_metric("f1_score", f1)
        
        # Log the model - this is crucial for seeing it in MLflow
        mlflow.sklearn.log_model(model, artifact_path="model")
        
        print(f"{model_name} logged to MLflow")
        return accuracy


def main():
    """Main function to run the MLflow workflow"""
    # Get the directory where this script is located
    import os
    
    # Debug information to help diagnose path issues
    current_dir = os.getcwd()
    print(f"Current working directory: {current_dir}")
    
    # List files in the data directory to verify
    try:
        print("Files in ./data directory:")
        print(os.listdir("./data"))
    except Exception as e:
        print(f"Error listing ./data directory: {e}")
    
    # Try using an absolute path instead of a relative one
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_path = os.path.join(script_dir, "data", "fraud_detection_dataset.csv")
    print(f"Trying absolute path: {data_path}")
    
    # Check if file exists before attempting to read it
    if os.path.exists(data_path):
        print(f"File found: {data_path}")
    else:
        print(f"File not found at: {data_path}")
        # Try alternate location (parent directory)
        data_path = os.path.join(os.path.dirname(script_dir), "data", "fraud_detection_dataset.csv")
        print(f"Trying alternate path: {data_path}")
        if os.path.exists(data_path):
            print(f"File found at alternate location: {data_path}")
        else:
            print("File not found at alternate location either")
            # As a last resort, ask user for input
            print("Please provide the full path to the CSV file:")
            data_path = input("> ")
    
    # Set the tracking URI - this must match your MLflow server
    mlflow.set_tracking_uri(uri="http://127.0.0.1:5000")
    print(f"MLflow tracking URI: {mlflow.get_tracking_uri()}")
    
    # Create or set the experiment name
    experiment_name = "Fraud Detection"
    mlflow.set_experiment(experiment_name)
    print(f"MLflow experiment: {experiment_name}")
    
    # Load and preprocess data
    X_train, X_test, y_train, y_test = load_and_preprocess_data(data_path)
    
    # Train and log models
    models = {
        "LogisticRegression": LogisticRegression(max_iter=1000),
        "RandomForest": RandomForestClassifier(n_estimators=100, random_state=42)
    }
    
    results = {}
    for name, model in models.items():
        accuracy = train_and_log_model(model, name, X_train, y_train, X_test, y_test)
        results[name] = accuracy
    
    # Print summary of results
    print("\nModel Performance Summary:")
    for name, accuracy in results.items():
        print(f"{name}: Accuracy = {accuracy:.4f}")
    
    best_model = max(results, key=results.get)
    print(f"\nBest model: {best_model} with accuracy {results[best_model]:.4f}")
    
    print("\nMLflow experiment completed successfully!")
    print(f"View the results at: {mlflow.get_tracking_uri()}/#/experiments/{mlflow.get_experiment_by_name(experiment_name).experiment_id}")


if __name__ == "__main__":
    main()
