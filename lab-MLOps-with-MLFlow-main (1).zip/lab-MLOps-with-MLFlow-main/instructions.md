# MLOps Lab: Experiment Tracking, Model Versioning, and Deployment with MLflow

**Duration:** 90 minutes

**Authors:** Claudio Canales

-----

# Table of Contents

1.  [Learning Objectives](#learning-objectives)
2.  [Prerequisites](#prerequisites)
3.  [Lab Environment](#lab-environment)
4.  [Scenario](#scenario)
5.  [Lab Outline](#lab-outline)
    *   [Part 1: Project Setup and Data Preparation (15 minutes)](#part-1-project-setup-and-data-preparation-15-minutes)
        *   [1. Introduction (5 minutes)](#1-introduction-5-minutes)
        *   [2. Project Setup on Jupyter Instance (5 minutes)](#2-project-setup-on-jupyter-instance-5-minutes)
        *   [3. Data Loading and Exploration (5 minutes)](#3-data-loading-and-exploration-5-minutes)
    *   [Part 2: Model Training and Experiment Tracking with MLflow (35 minutes)](#part-2-model-training-and-experiment-tracking-with-mlflow-35-minutes)
        *   [1. Introduction to MLflow Tracking (5 minutes)](#1-introduction-to-mlflow-tracking-5-minutes)
        *   [2. Model Training Script (20 minutes)](#2-model-training-script-20-minutes)
        *   [3. Running and Tracking Experiments (10 minutes)](#3-running-and-tracking-experiments-10-minutes)
    *   [Part 3: Model Packaging and Deployment with Flask (35 minutes)](#part-3-model-packaging-and-deployment-with-flask-35-minutes)
        *   [1. Introduction to MLflow Models (5 minutes)](#1-introduction-to-mlflow-models-5-minutes)
        *   [2. Creating a Model Serving API with Flask (20 minutes)](#2-creating-a-model-serving-api-with-flask-20-minutes)
        *   [3. Running the Flask Server in the Background (5 minutes)](#3-running-the-flask-server-in-the-background-5-minutes)
        *   [4. Testing the API (5 minutes)](#4-testing-the-api-5-minutes)
6.  [VI. Conclusion and Where to Go Next (5 minutes)](#vi-conclusion-and-where-to-go-next-5-minutes)
    *   [A. Recap of Key Takeaways](#a-recap-of-key-takeaways)
    *   [B. Where to Go Next](#b-where-to-go-next)

## Learning Objectives

By the end of this lab, you will be able to:

-   ✅ Set up a basic ML project environment on an AWS Jupyter instance.
-   ✅ Use MLflow to track and log parameters, metrics, and artifacts during model training.
-   ✅ Package a trained machine learning model using MLflow's standard model format.
-   ✅ Create a simple REST API using Flask to serve predictions from an MLflow-packaged model.
-   ✅ Understand the basic workflow of deploying a model in a simplified manner.
-   ✅ Run and test a model-serving API locally.
-   ✅ Gain practical experience with core MLOps concepts, including experiment tracking, model versioning, and simplified deployment.
-   ✅ Relate the hands-on lab activities to the theoretical concepts learned in the "AI Model Deployment" and "MLOps Fundamentals" lessons.


**Prerequisites:**

-   Basic Python programming knowledge.
-   Familiarity with machine learning concepts (e.g., training, testing, evaluation).
-   An AWS account with access to a Jupyter instance

**Lab Environment:**

-   AWS Jupyter instance with Python 3.11.9.
-   We will be using a public dataset.
-   **Important:** We will run the Flask server in the background within the Jupyter instance for simplicity. In a real-world scenario, you would deploy it separately.

**Scenario:** We will build a simplified MLOps pipeline for a customer churn prediction model for a telecommunications company, putting into practice the concepts learned in the previous lessons.

## Lab Outline:

**(Total Time: 90 minutes)**

**Part 1: Project Setup and Data Preparation (15 minutes)**

1.  **Introduction (5 minutes):**
    -   **Welcome and Overview:** Briefly review the lab scenario (customer churn prediction) and objectives. Emphasize that we'll be focusing on core MLOps principles using MLflow in a simplified, hands-on manner, reinforcing the concepts from the previous lessons.
    -   **Introduce the Dataset:** We'll use the [Telco Customer Churn dataset](https://www.kaggle.com/datasets/aadityabansalcodes/telecommunications-industry-customer-churn-dataset/data) from Kaggle. Explain that it's publicly available and contains information about customer demographics, services, and churn status.
        -   **Dataset Features:** Briefly describe the key features: `customerID`, `gender`, `SeniorCitizen`, `Partner`, `Dependents`, `tenure`, `PhoneService`, `MultipleLines`, `InternetService`, `OnlineSecurity`, `OnlineBackup`, `DeviceProtection`, `TechSupport`, `StreamingTV`, `StreamingMovies`, `Contract`, `PaperlessBilling`, `PaymentMethod`, `MonthlyCharges`, `TotalCharges`, `Churn` (target variable).
    -   **Discuss Data Versioning (Conceptually):** Explain that in a real-world scenario, you would use a data versioning tool like DVC. Here, we'll keep it simple and focus on tracking code and model versions.
    -   **Explain the Importance of Data Preprocessing:** Briefly mention that data preprocessing is crucial but will be kept basic to focus on MLOps.

2.  **Project Setup on Jupyter Instance (5 minutes):**
    - launch the environment
    ```bash
        python3 -m venv env
    ```
    - activate the envinronment
     ```bash
        source env/bin/activate
    ```
    -   **Install Libraries:** Provide the `pip install` command:
        ```bash
        pip install notebook==6.5.7 mlflow scikit-learn pandas flask boto3
        ```
    -   **Create Directories:** Use `mkdir -p data model` to create directories for data and models.
    -   **Set up Git (Optional but Recommended):** If comfortable with Git, initialize a repository: `git init` and add a `.gitignore`.

3.  **Data Loading and Exploration (5 minutes):**
    
    -   **Download the Dataset:** Provide the command to download the dataset directly from the Iguazio S3 bucket:

        ```bash
        wget --no-verbose https://iguazio-sample-data.s3.amazonaws.com/datasets/WA_Fn-UseC_-Telco-Customer-Churn.csv -O data/WA_Fn-UseC_-Telco-Customer-Churn.csv
        ```

        -   **Explanation of the change:**
            -   `!wget`: Executes the `wget` command in the Jupyter notebook cell.
            -   `--no-verbose`: Makes the download less verbose in the output.
            -   `https://iguazio-sample-data.s3.amazonaws.com/datasets/WA_Fn-UseC_-Telco-Customer-Churn.csv`: This is the direct URL to the dataset in the S3 bucket.
            -   `-O data/WA_Fn-UseC_-Telco-Customer-Churn.csv`: Specifies the output path and filename to save the downloaded dataset. 

            **Open jupyter notebook.**

        ```bash
        jupyter notebook
        ```
        **Create a new jupyter notebook**

        From the notebook ui, create a new notebook with python3.


    -   **Load with Pandas:** Use `pd.read_csv()` to load the dataset.
    -   **Brief Exploration:** Encourage using `data.head()`, `data.info()`, `data.describe()`, and `data.isnull().sum()`.

**Complete Code Example (Part 1):**

```python
# Cell 1: Install Libraries
# !pip install mlflow scikit-learn pandas flask boto3 # already installed

# Cell 2: Create directories
# !mkdir -p data model # already executed

# Cell 3: Download the Data from Iguazio S3
!wget --no-verbose https://iguazio-sample-data.s3.amazonaws.com/datasets/WA_Fn-UseC_-Telco-Customer-Churn.csv -O data/WA_Fn-UseC_-Telco-Customer-Churn.csv

# Cell 4: Load and Explore Data
import pandas as pd

# Load data
data = pd.read_csv("data/WA_Fn-UseC_-Telco-Customer-Churn.csv")

# Display the first few rows
print(data.head())

# Check for missing values
print(data.isnull().sum())

# Get basic info about the data
print(data.info())

# Describe the data
print(data.describe())
```

**Part 2: Model Training and Experiment Tracking with MLflow (35 minutes)**

1.  **Introduction to MLflow Tracking (5 minutes):**
    -   **Explain MLflow Components:** Briefly introduce Tracking, Projects, Models, and Registry. Highlight that we'll focus on Tracking and Models.
    -   **MLflow Tracking Concepts:**
        -   **Run:** A single execution of model training code.
        -   **Parameters:** Input parameters (e.g., hyperparameters).
        -   **Metrics:** Evaluation metrics (e.g., accuracy, precision).
        -   **Artifacts:** Output files (e.g., models, plots).
    -   **Demonstrate `mlflow.start_run()`:** Show how to start and end an MLflow run using a context manager.
    -   **Demonstrate Logging:**
        -   `mlflow.log_param()`, `mlflow.log_params()`: Log parameters.
        -   `mlflow.log_metric()`, `mlflow.log_metrics()`: Log metrics.
        -   `mlflow.log_artifact()`: Log files.
    -   **Explain the MLflow UI:** Mention that the UI visualizes and compares runs (we'll explore it later).

2.  **Model Training Script (20 minutes):**
    -   We have to create `train.py` on `lab04` folder
    -   **Provide the full code for `train.py`:**

```python
import mlflow
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from sklearn.preprocessing import StandardScaler, LabelEncoder
import os


# Load and preprocess data
def load_and_preprocess_data(data_path):
    data = pd.read_csv(data_path)

    # Drop unnecessary columns
    data = data.drop(['customerID'], axis=1)

    # Convert TotalCharges to numeric, setting errors='coerce' to turn invalid parsing into NaN
    data['TotalCharges'] = pd.to_numeric(data['TotalCharges'], errors='coerce')

    # Fill NaN values in TotalCharges with the mean (or another strategy)
    data['TotalCharges'].fillna(data['TotalCharges'].mean(), inplace=True)

    # Handle the Churn column first - before one-hot encoding other categoricals
    # Check for missing values in Churn
    if data['Churn'].isnull().any():
        raise ValueError("Found missing values in the Churn column")

    # Map Churn values explicitly
    churn_map = {'No': 0, 'Yes': 1}
    if not all(data['Churn'].isin(churn_map.keys())):
        raise ValueError("Unexpected values found in Churn column. Expected 'Yes' or 'No'")
    data['Churn'] = data['Churn'].map(churn_map)

    # Get all categorical columns except Churn
    categorical_cols = data.select_dtypes(include=['object']).columns
    # One-hot encode remaining categorical features
    data = pd.get_dummies(data, columns=categorical_cols, drop_first=True)

    return data


# Split data into features (X) and target (y)
def split_data(data, target_column):
    X = data.drop(target_column, axis=1)
    y = data[target_column]
    return X, y


if __name__ == "__main__":
    # Set the data path
    data_path = "data/WA_Fn-UseC_-Telco-Customer-Churn.csv"

    # Check if the data file exists
    if not os.path.isfile(data_path):
        print(f"Error: Data file not found at {data_path}")
        exit()

    # Load and preprocess the data
    try:
        data = load_and_preprocess_data(data_path)
    except Exception as e:
        print(f"Error preprocessing data: {e}")
        exit()

    # Split the data
    try:
        X, y = split_data(data, "Churn")
    except Exception as e:
        print(f"Error splitting data: {e}")
        exit()

    # Split data into training and testing sets
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Scale numerical features
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    # Start an MLflow run
    with mlflow.start_run():
        # Define hyperparameters
        params = {
            "penalty": "l2",
            "C": 0.1,
            "solver": "liblinear",
            "random_state": 42
        }

        # Log parameters
        mlflow.log_params(params)

        # Train the model
        model = LogisticRegression(**params)
        model.fit(X_train_scaled, y_train)

        # Make predictions
        y_pred = model.predict(X_test_scaled)

        # Evaluate the model
        accuracy = accuracy_score(y_test, y_pred)
        precision = precision_score(y_test, y_pred)
        recall = recall_score(y_test, y_pred)
        f1 = f1_score(y_test, y_pred)

        # Log metrics
        mlflow.log_metric("accuracy", accuracy)
        mlflow.log_metric("precision", precision)
        mlflow.log_metric("recall", recall)
        mlflow.log_metric("f1", f1)

        # Log the model
        mlflow.sklearn.log_model(model, "model")

        # Print out the model metrics
        print("\nModel Performance Metrics:")
        print(f"Accuracy: {accuracy:.4f}")
        print(f"Precision: {precision:.4f}")
        print(f"Recall: {recall:.4f}")
        print(f"F1-score: {f1:.4f}")
```

-   **Code Explanation:**
    -   Loads and preprocesses data (basic cleaning and one-hot encoding).
    -   Splits data into training and testing sets.
    -   Trains a `LogisticRegression` model.
    -   **MLflow Integration:**
        -   `with mlflow.start_run():` starts a new MLflow run.
        -   `mlflow.log_params(params)`: Logs hyperparameters.
        -   `mlflow.log_metric()`: Logs evaluation metrics.
        -   `mlflow.sklearn.log_model(model, "model")`: Logs the trained model.

3.  **Running and Tracking Experiments (10 minutes):**
    -   **Execution:** Execute `train.py` from the notebook using `!python3 train.py` or in notebook cells.
    -   **MLflow UI:** Open the MLflow UI:
        -   In a new terminal, activate the virtual environment and then run: `mlflow ui`.
        -   The UI will be available at `http://localhost:5000`.
    -   **Exploration:** Show how to:
        -   View the list of runs.
        -   Compare runs based on parameters and metrics.
        -   Examine details of a run (parameters, metrics, artifacts).
        -   Click on the "model" artifact to see the logged model's information.
    -   **Experimentation:** Encourage participants to:
        -   Modify hyperparameters in `train.py` (e.g., change `C`).
        -   Re-run the training script.
        -   Observe how new runs are tracked in the UI.
        -   Compare model performance with different hyperparameters.

**Part 3: Model Packaging and Deployment with Flask (35 minutes)**

1.  **Introduction to MLflow Models (5 minutes):**
    -   **MLflow Models Format:** Explain that MLflow Models provide a standard way to package models.
    -   **`model` Directory Structure:** Show the structure of the `model` directory (created by `mlflow.sklearn.log_model()`):
        -   `MLmodel` (YAML): Describes the model's format, signature, and environment.
        -   `model.pkl`: The serialized model file.
        -   `conda.yaml` or `requirements.txt`: Specifies Python dependencies.
    -   **Model Signature:** Briefly explain the concept of a model signature (input and output schema).

2.  **Creating a Model Serving API with Flask (20 minutes):**
    -   Create `serve.py` or work in notebook cells.
    -   **Provide the full code for `serve.py`:**

```python
from flask import Flask, request, jsonify
import mlflow.pyfunc
import pandas as pd
import os

app = Flask(__name__)

# Get the latest logged model from MLflow
def get_latest_model():

    # Set the tracking uri to the where MLFlow is running
    mlflow_tracking_uri = 'http://localhost:5000'

    if mlflow_tracking_uri is None:
        # Handle the case where the environment variable is not set
        print("Error: MLFLOW_TRACKING_URI environment variable not set.")
        return None  # Or raise an exception

    # Set the tracking URI for MLflow
    mlflow.set_tracking_uri(mlflow_tracking_uri)

    runs = mlflow.search_runs(filter_string="metrics.accuracy > 0.5", order_by=["metrics.accuracy DESC"], max_results=1) # Set your threshold

    if runs.empty:
        return None

    run_id = runs.iloc[0]["run_id"]
    model_uri = f"runs:/{run_id}/model"
    return mlflow.pyfunc.load_model(model_uri)

model = get_latest_model()

@app.route("/predict", methods=["POST"])
def predict():
    try:
        data = request.get_json()

        # Convert the incoming JSON data to a Pandas DataFrame
        data_df = pd.DataFrame(data)

        # Make predictions using the loaded model
        predictions = model.predict(data_df)

        # Convert predictions to a list before returning as JSON
        return jsonify(predictions.tolist())

    except Exception as e:
        return jsonify({"error": str(e)})

if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=8080)
```

-   **Code Explanation:**
    -   **Imports:** `flask`, `mlflow.pyfunc`, `pandas`.
    -   **`get_latest_model()` function:**
        -   Retrieves the MLflow tracking URI from environment variable.
        -   Sets the MLflow tracking URI.
        -   Searches for the most recent run that meets the accuracy criteria.
        -   Constructs the model URI using the `run_id`.
        -   Loads the model using `mlflow.pyfunc.load_model()`.
    -   **Flask App:** Creates a Flask app.
    -   **`/predict` Endpoint:**
        -   Defines `/predict` route that accepts POST requests with JSON data.
        -   Converts JSON data to a Pandas DataFrame.
        -   Calls `model.predict()` to make predictions.
        -   Returns predictions as a JSON response.

3.  **Running the Flask Server in the Background (5 minutes):**
    -   Run Flask in the background within Jupyter for simplicity.
    -   **Important:** Remind participants this is not a production-ready strategy.
    -   Use this code in a cell:



  

4.  **Testing The API**

On the AWS workspace, in the bottom left of the screen, click on "Applications", then select postman from the "Programming" tab. 

Select the lightweight version to continue with postman. 

Select POST from the dropdown for the HTTP verb and enter `http://localhost:5000/predict` as the request url.

From the body tab, select json as the format (from the dropdown) and enter the following json as the request body:

```json
[
    {
        "SeniorCitizen": 0,
        "tenure": 1,
        "MonthlyCharges": 29.85,
        "TotalCharges": 29.85,
        "Partner_Yes": 1,
        "Dependents_Yes": 0,
        "PhoneService_Yes": 0,
        "MultipleLines_No phone service": 1,
        "MultipleLines_Yes": 0,
        "OnlineSecurity_No internet service": 0,
        "OnlineSecurity_Yes": 0,
        "OnlineBackup_No internet service": 0,
        "OnlineBackup_Yes": 1,
        "DeviceProtection_No internet service": 0,
        "DeviceProtection_Yes": 0,
        "TechSupport_No internet service": 0,
        "TechSupport_Yes": 0,
        "StreamingTV_No internet service": 0,
        "StreamingTV_Yes": 0,
        "StreamingMovies_No internet service": 0,
        "StreamingMovies_Yes": 0,
        "PaperlessBilling_Yes": 1,
        "InternetService_DSL": 0,
        "InternetService_Fiber optic": 0,
        "InternetService_No": 0,
        "Contract_One year": 0,
        "Contract_Two year": 0,
        "PaymentMethod_Credit card (automatic)": 0,
        "PaymentMethod_Electronic check": 1,
        "PaymentMethod_Mailed check": 0
    }
]
```

Hit the send button and you should see the prediction returned. 


**Discussion Points:**

-   **How does this lab demonstrate core MLOps principles?** (Automation, version control, experiment tracking, model management, simplified deployment). Relate this back to the principles discussed in the "MLOps Fundamentals" lesson.
-   **What are the limitations of this deployment?** (Not scalable, no robust monitoring, basic error handling).
-   **How could this be extended to a production-ready pipeline?** (Workflow orchestrator, containerization, cloud deployment, monitoring tools, CI/CD). Connect this to the deployment architectures and strategies from the "AI Model Deployment" lesson.
-   **Trade-offs between simple local deployment (Flask) vs. complex cloud deployment?** (Scalability, cost, management, latency).

---

## VI. Conclusion and Where to Go Next (5 minutes)

### A. Recap of Key Takeaways

-   **MLflow is a valuable tool for experiment tracking, model management, and packaging.** It simplifies key aspects of the ML lifecycle.
-   **Experiment tracking helps understand and improve models.** Logging parameters, metrics, and artifacts with MLflow enables systematic experimentation and comparison of different model versions.
-   **Model packaging with MLflow standardizes model deployment.** The MLflow Model format ensures that models can be easily deployed across different platforms.
-   **Flask provides a simple way to create a REST API for model serving.** This demonstrates the basic principles of exposing a model for inference.
-   **This lab provides a foundation for building more complex MLOps pipelines.** It demonstrates core MLOps principles in a practical, hands-on manner.

### B. Where to Go Next

-   **Explore more advanced MLflow features:** Investigate MLflow Projects for packaging code and dependencies, and MLflow Registry for managing the model lifecycle.
-   **Implement a more robust deployment:** Learn about containerization with Docker and orchestration with Kubernetes for scalable and reliable deployments. Consider cloud-based deployment options like SageMaker Hosting or Azure ML managed endpoints.
-   **Incorporate CI/CD:** Integrate your MLflow workflow into a CI/CD pipeline for automated testing and deployment.
-   **Set up model monitoring:** Implement monitoring to track model performance and data drift in a production setting. Use tools like Prometheus and Grafana or cloud-based monitoring services.
-   **Experiment with different model serving frameworks:** Explore TensorFlow Serving, TorchServe, or other frameworks for serving models.
-   **Dive deeper into data versioning:** Learn about tools like DVC to manage and version your datasets.
-   **Address the limitations:** Consider how you would address the limitations of the simplified deployment approach used in this lab in a real-world scenario. Think about scalability, fault tolerance, security, and monitoring.
-   **Multi-Environment Deployments:** As a logical next challenge, explore how to manage and deploy models across different environments (Development, Staging, Production) using MLflow and potentially a CI/CD pipeline.
-   **Advanced MLflow Features:** Learn about more advanced MLflow features such as Projects for reproducible runs, and the Model Registry for managing the model lifecycle and collaborating on models.

By continuing to learn and experiment, you can build upon the foundation established in this lab and develop increasingly sophisticated MLOps pipelines, ultimately enabling you to deploy and manage AI models effectively and deliver real business value.
