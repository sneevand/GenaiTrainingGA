# day-5-capstone-lab

**Lab Objective:**
Develop an AI-driven solution strategy tailored to a specific business problem.

**Scenario:**

Your healthcare client is struggling to predict patient readmissions. Develop an AI solution to address this issue, and
prepare a proposal highlighting the business value.

**Students will:**

- Define the problem and business goals.
- Select an AI architecture and justify their choice.
- Outline a data strategy, deployment plan, and risk mitigation strategies.
- Use Hospital Readmission data to create a working model that addresses the clients problem.
- Create a 5-minute pitch to deliver to the client or internal stakeholders (optional)

> The data used in this lab comes
> from [kaggle.com](https://www.kaggle.com/code/iabhishekofficial/prediction-on-hospital-readmission/input)

### Lab Setup Instructions

1. **Navigate to the Project Directory:**
   ```bash
   cd day-5-capstone-lab
   ```

2. **Create a Virtual Environment:**
   ```bash
   python3 -m venv env
   ```

3. **Activate the Virtual Environment:**
   ```bash
   source env/bin/activate
   ```

4. **Install Required Packages:**
   ```bash
   pip install -r requirements.txt
   ```

5. **Launch Jupyter Notebook:**
   ```bash
   jupyter notebook
   ```

6. **Open the Starter IPython Notebook:**
    - In the Jupyter interface, navigate to the starter notebook to begin the lab.